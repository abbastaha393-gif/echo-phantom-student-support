# Echo Phantom Student Support — Vercel Edition

This Vercel-compatible edition uses standard Next.js, Supabase Postgres for project data, and a private Supabase Storage bucket for Demo SRS files.

## 1. Create the Supabase backend

1. Create or open a Supabase project.
2. Open **SQL Editor**.
3. Copy everything from `supabase/schema.sql`.
4. Paste it into the SQL Editor and click **Run**.
5. Open **Project Settings → API** and copy the Project URL and service-role key.

The service-role key is server-only. Never expose it in browser code or rename it with a `NEXT_PUBLIC_` prefix.

## 2. Configure locally

1. Copy `.env.example` to `.env.local`.
2. Fill in all three values.
3. Generate `SESSION_SECRET` with a password generator or `openssl rand -hex 32`.
4. Run:

```bash
pnpm install
pnpm build
pnpm dev
```

## 3. Deploy to Vercel

1. Upload this folder to a GitHub repository.
2. In Vercel, click **Add New → Project** and import the repository.
3. Keep **Framework Preset: Next.js**.
4. Add these Environment Variables for Production, Preview, and Development:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `SUPABASE_SERVICE_ROLE_KEY`
   - `SESSION_SECRET`
5. Click **Deploy**.

## Admin login

- Name: `adminTaha`
- Roll number: `SoftF24BSS59`

## Included features

- 500 built-in development project ideas
- Student login with flexible department roll-number codes
- Global project booking and admin booking reversal
- Bulk idea import
- Private Demo SRS uploads and downloads
- WhatsApp SRS request flow
- Responsive Echo Phantom interface
