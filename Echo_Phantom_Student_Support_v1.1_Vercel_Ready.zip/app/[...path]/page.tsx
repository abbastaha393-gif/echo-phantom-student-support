import StudentSupportApp from "../student-support-app";

export default function RoutedPage() {
  return <StudentSupportApp />;
}
