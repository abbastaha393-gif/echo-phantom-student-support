import { NextResponse } from "next/server";
import { clearSession, createSession, getSession } from "@/lib/session";

export async function GET() { return NextResponse.json({ session: await getSession() }); }
export async function POST(request: Request) {
  const body = await request.json() as { name?: string; rollNumber?: string };
  const name = body.name?.trim() || "";
  const rollNumber = body.rollNumber?.trim().replace(/\s+/g, "").replace(/[.,;:]+$/g, "") || "";
  if (!name || !rollNumber) return NextResponse.json({ error: "Enter your name and university roll number." }, { status: 400 });
  const isAdmin = name.toLowerCase() === "admintaha" && rollNumber.toLowerCase() === "softf24bss59";
  await createSession({ name, rollNumber, isAdmin });
  return NextResponse.json({ session: { name, rollNumber, isAdmin } });
}
export async function DELETE() { await clearSession(); return NextResponse.json({ ok: true }); }
