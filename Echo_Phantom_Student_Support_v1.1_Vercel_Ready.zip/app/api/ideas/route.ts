import { NextResponse } from "next/server";
import { getSession } from "@/lib/session";
import { getSupabaseAdmin } from "@/lib/supabase-admin";

export async function GET() {
  try {
    const supabase = getSupabaseAdmin();
    const [bookedResult, customResult] = await Promise.all([
      supabase.from("bookings").select("idea_id"),
      supabase.from("custom_ideas").select("id,title,description,category").order("id", { ascending: false }),
    ]);
    if (bookedResult.error) throw bookedResult.error;
    if (customResult.error) throw customResult.error;
    return NextResponse.json({
      booked: (bookedResult.data || []).map((row) => row.idea_id),
      custom: customResult.data || [],
    });
  } catch {
    return NextResponse.json({ error: "Project data is temporarily unavailable.", booked: [], custom: [] }, { status: 503 });
  }
}

export async function POST(request: Request) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Please log in first." }, { status: 401 });
  const body = await request.json() as { action?: string; ideaId?: string; ideas?: Array<{ title: string; description: string; category: string }> };
  const supabase = getSupabaseAdmin();

  if (body.action === "book" && body.ideaId) {
    const { error } = await supabase.from("bookings").insert({
      idea_id: body.ideaId,
      student_name: session.name,
      roll_number: session.rollNumber,
    });
    if (error?.code === "23505") return NextResponse.json({ error: "This idea has already been booked." }, { status: 409 });
    if (error) return NextResponse.json({ error: "The booking could not be saved." }, { status: 500 });
    return NextResponse.json({ ok: true });
  }

  if (body.action === "add" && session.isAdmin && body.ideas?.length) {
    const ideas = body.ideas.slice(0, 200).map((idea) => ({
      title: idea.title,
      description: idea.description,
      category: idea.category || "Custom",
    }));
    const { error } = await supabase.from("custom_ideas").insert(ideas);
    if (error) return NextResponse.json({ error: "The ideas could not be added." }, { status: 500 });
    return NextResponse.json({ added: ideas.length });
  }

  if (body.action === "unbook" && session.isAdmin && body.ideaId) {
    const { data, error } = await supabase.from("bookings").delete().eq("idea_id", body.ideaId).select("idea_id");
    if (error) return NextResponse.json({ error: "The booking could not be reversed." }, { status: 500 });
    if (!data?.length) return NextResponse.json({ error: "This project is already available." }, { status: 404 });
    return NextResponse.json({ ok: true });
  }

  return NextResponse.json({ error: "Invalid request." }, { status: 400 });
}
