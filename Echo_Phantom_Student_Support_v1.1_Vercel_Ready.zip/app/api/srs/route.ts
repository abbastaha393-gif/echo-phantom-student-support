import { NextResponse } from "next/server";
import { getSession } from "@/lib/session";
import { getSupabaseAdmin } from "@/lib/supabase-admin";

const BUCKET = "demo-srs";

export async function GET(request: Request) {
  const supabase = getSupabaseAdmin();
  const key = new URL(request.url).searchParams.get("key");
  if (key) {
    const { data, error } = await supabase.storage.from(BUCKET).download(key);
    if (error || !data) return new NextResponse("Not found", { status: 404 });
    const record = await supabase.from("demo_srs").select("file_name,content_type").eq("object_key", key).maybeSingle();
    return new NextResponse(data, {
      headers: {
        "content-type": record.data?.content_type || data.type || "application/octet-stream",
        "content-disposition": `inline; filename="${record.data?.file_name || "demo-srs"}"`,
      },
    });
  }
  const { data, error } = await supabase.from("demo_srs").select("title,object_key,file_name,content_type,created_at").order("id", { ascending: false });
  if (error) return NextResponse.json({ error: "Demo SRS files are temporarily unavailable.", files: [] }, { status: 503 });
  return NextResponse.json({ files: data || [] });
}

export async function POST(request: Request) {
  const session = await getSession();
  if (!session?.isAdmin) return NextResponse.json({ error: "Admin access required." }, { status: 403 });
  const form = await request.formData();
  const file = form.get("file");
  const title = String(form.get("title") || "Demo SRS").trim();
  if (!(file instanceof File) || file.size === 0 || file.size > 15 * 1024 * 1024) return NextResponse.json({ error: "Choose a PDF or DOCX file up to 15 MB." }, { status: 400 });
  const allowed = ["application/pdf", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"];
  if (!allowed.includes(file.type)) return NextResponse.json({ error: "Only PDF and DOCX files are accepted." }, { status: 400 });

  const supabase = getSupabaseAdmin();
  const key = `${crypto.randomUUID()}-${file.name.replace(/[^a-zA-Z0-9._-]/g, "-")}`;
  const { error: uploadError } = await supabase.storage.from(BUCKET).upload(key, await file.arrayBuffer(), {
    contentType: file.type,
    upsert: false,
  });
  if (uploadError) return NextResponse.json({ error: "The file could not be uploaded." }, { status: 500 });

  const { error: insertError } = await supabase.from("demo_srs").insert({
    title,
    object_key: key,
    file_name: file.name,
    content_type: file.type,
  });
  if (insertError) {
    await supabase.storage.from(BUCKET).remove([key]);
    return NextResponse.json({ error: "The file details could not be saved." }, { status: 500 });
  }
  return NextResponse.json({ ok: true });
}
