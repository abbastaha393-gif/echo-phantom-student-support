import StudentSupportApp from "./student-support-app";

export default function Home() {
  return <StudentSupportApp />;
}
