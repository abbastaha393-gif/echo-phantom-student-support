"use client";

import { useEffect, useMemo, useState } from "react";
import { ArrowRight, BookMarked, BookOpen, Check, ChevronLeft, ChevronRight, Code2, FileText, Filter, GraduationCap, LayoutDashboard, LockKeyhole, LogIn, LogOut, Menu, MessageCircle, Plus, RotateCcw, Search, ShieldCheck, Sparkles, Upload, UserRound, X } from "lucide-react";
import { builtInIdeas, categories, type Idea } from "@/lib/ideas";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast, Toaster } from "sonner";

type Session = { name: string; rollNumber: string; isAdmin: boolean };
type DemoFile = { title: string; object_key: string; file_name: string; created_at: string };
const PAGE_SIZE = 12;

function parseIdeas(text: string) {
  return text.split(/\n+/).map((line) => line.trim()).filter(Boolean).map((line) => {
    const clean = line.replace(/^\d+[.)]\s*/, "");
    const parts = clean.split(/\s[-–—:]\s/);
    return { title: parts[0]?.trim(), description: parts.slice(1).join(" — ").trim() || "A practical development project with a working prototype and measurable evaluation.", category: "Custom" };
  }).filter((item) => item.title);
}

export default function StudentSupportApp() {
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [booked, setBooked] = useState<string[]>([]);
  const [custom, setCustom] = useState<Idea[]>([]);
  const [files, setFiles] = useState<DemoFile[]>([]);
  const [route, setRoute] = useState("/");
  const [menu, setMenu] = useState(false);
  const [loginOpen, setLoginOpen] = useState(false);
  const [selected, setSelected] = useState<Idea | null>(null);
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("All");
  const [page, setPage] = useState(1);

  const navigate = (path: string) => { history.pushState({}, "", path); setRoute(path); setMenu(false); window.scrollTo({ top: 0, behavior: "smooth" }); };
  const loadData = async () => {
    const [auth, ideas, srs] = await Promise.all([fetch("/api/auth").then((r) => r.json()), fetch("/api/ideas").then((r) => r.json()), fetch("/api/srs").then((r) => r.json())]);
    setSession(auth.session || null); setBooked(ideas.booked || []);
    setCustom((ideas.custom || []).map((idea: any) => ({ id: `CUSTOM-${idea.id}`, title: idea.title, description: idea.description, category: idea.category })));
    setFiles(srs.files || []); setLoading(false);
  };
  useEffect(() => {
    setRoute(location.pathname);
    const pop = () => setRoute(location.pathname);
    addEventListener("popstate", pop); loadData().catch(() => setLoading(false));
    const context = (document as any).modelContext;
    const lifecycle = new AbortController();
    if (context?.registerTool) {
      Promise.resolve(context.registerTool({
        name: "search_project_ideas", title: "Search project ideas",
        description: "Search the 500 final-year development project ideas by keyword.",
        inputSchema: { type: "object", properties: { query: { type: "string" } }, required: ["query"], additionalProperties: false },
        annotations: { readOnlyHint: true, untrustedContentHint: false },
        execute: ({ query: q }: { query: string }) => {
          const results = builtInIdeas.filter((idea) => `${idea.title} ${idea.description}`.toLowerCase().includes(q.toLowerCase())).slice(0, 10);
          setQuery(q); navigate("/"); return { count: results.length, results };
        }
      }, { signal: lifecycle.signal })).catch(() => {});
    }
    return () => { removeEventListener("popstate", pop); lifecycle.abort(); };
  }, []);

  const allIdeas = useMemo(() => [...custom, ...builtInIdeas].map((idea) => ({ ...idea, booked: booked.includes(idea.id) })), [custom, booked]);
  const filtered = useMemo(() => allIdeas.filter((idea) => (category === "All" || idea.category === category) && `${idea.title} ${idea.description} ${idea.id}`.toLowerCase().includes(query.toLowerCase())), [allIdeas, category, query]);
  const pages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const visible = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);
  useEffect(() => setPage(1), [query, category]);

  const login = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const response = await fetch("/api/auth", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ name: data.get("name"), rollNumber: data.get("rollNumber") }) });
    const result = await response.json();
    if (!response.ok) return toast.error(result.error);
    setSession(result.session); setLoginOpen(false); toast.success(`Welcome, ${result.session.name}`);
    if (result.session.isAdmin) navigate("/admin");
  };
  const logout = async () => { await fetch("/api/auth", { method: "DELETE" }); setSession(null); navigate("/"); };
  const book = async (idea: Idea) => {
    if (!session) { setLoginOpen(true); return; }
    const response = await fetch("/api/ideas", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action: "book", ideaId: idea.id }) });
    const result = await response.json();
    if (!response.ok) return toast.error(result.error);
    setBooked((current) => [...current, idea.id]); setSelected({ ...idea, booked: true }); toast.success("Idea booked successfully");
  };

  return (
    <div className="min-h-screen bg-[#07111f] text-white">
      <Toaster richColors position="top-center" />
      <header className="sticky top-0 z-40 border-b border-white/10 bg-[#07111f]/92 backdrop-blur-xl">
        <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-5">
          <button onClick={() => navigate("/")} className="flex items-center gap-3 text-left">
            <img src="/echo-logo.svg" alt="Echo Phantom" className="h-11 w-11 rounded-xl bg-white p-1.5" />
            <span><b className="block text-base tracking-wide">ECHO PHANTOM</b><small className="block text-xs tracking-[.22em] text-cyan-300">STUDENT SUPPORT</small></span>
          </button>
          <nav className="hidden items-center gap-1 lg:flex">
            {[["Ideas","/"],["Demo SRS","/demo-srs"],["About","/about"]].map(([label,path]) => <button key={path} onClick={() => navigate(path)} className={`rounded-xl px-4 py-2 text-sm font-semibold transition ${route === path ? "bg-cyan-300 text-[#07111f]" : "text-slate-300 hover:bg-white/8 hover:text-white"}`}>{label}</button>)}
            {session?.isAdmin && <button onClick={() => navigate("/admin")} className="rounded-xl px-4 py-2 text-sm font-semibold text-amber-300 hover:bg-amber-300/10">Admin Portal</button>}
          </nav>
          <div className="hidden items-center gap-3 lg:flex">
            {session ? <><span className="text-sm text-slate-300"><UserRound className="mr-1 inline h-4 w-4" />{session.name}</span><Button variant="outline" onClick={logout} className="border-white/15 bg-transparent text-white hover:bg-white/10"><LogOut /> Logout</Button></> : <Button onClick={() => setLoginOpen(true)} className="bg-cyan-300 text-[#06111e] hover:bg-cyan-200"><LogIn /> Student Login</Button>}
          </div>
          <button className="rounded-xl border border-white/10 p-2 lg:hidden" onClick={() => setMenu(!menu)}>{menu ? <X /> : <Menu />}</button>
        </div>
        {menu && <div className="border-t border-white/10 p-4 lg:hidden">{[["Ideas","/"],["Demo SRS","/demo-srs"],["About","/about"],...(session?.isAdmin ? [["Admin Portal","/admin"]] : [])].map(([label,path]) => <button key={path} onClick={() => navigate(path)} className="block w-full rounded-lg px-3 py-3 text-left">{label}</button>)}<Button onClick={() => session ? logout() : setLoginOpen(true)} className="mt-2 w-full bg-cyan-300 text-[#06111e]">{session ? "Logout" : "Student Login"}</Button></div>}
      </header>

      {loading ? <div className="grid min-h-[70vh] place-items-center"><div className="h-12 w-12 animate-spin rounded-full border-4 border-cyan-300 border-t-transparent" /></div> :
       route === "/about" ? <About /> :
       route === "/demo-srs" ? <DemoSrs files={files} /> :
       route === "/get-srs" ? <GetSrs /> :
       route === "/admin" ? <Admin session={session} reload={loadData} bookedIdeas={allIdeas.filter((idea) => idea.booked)} /> :
       <main>
        <section className="relative overflow-hidden border-b border-white/10">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_78%_18%,rgba(34,211,238,.19),transparent_32%),radial-gradient(circle_at_18%_80%,rgba(37,99,235,.16),transparent_28%)]" />
          <div className="relative mx-auto grid max-w-7xl gap-10 px-5 py-14 lg:grid-cols-[1.2fr_.8fr] lg:py-20">
            <div>
              <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-cyan-300/25 bg-cyan-300/8 px-4 py-2 text-sm font-medium text-cyan-200"><Sparkles className="h-4 w-4" /> 500 original development ideas</div>
              <h1 className="max-w-3xl text-4xl font-black leading-[1.05] tracking-tight sm:text-6xl">Find a final year project worth <span className="text-cyan-300">building.</span></h1>
              <p className="mt-5 max-w-2xl text-lg leading-8 text-slate-300">Explore practical, prototype-ready ideas beyond traditional POS, e-commerce, hostel, hospital, and generic management portals.</p>
            </div>
            <div className="grid grid-cols-2 gap-4 self-end">
              {[["500","Ideas",Code2],["20","Fields",Filter],["Rs 100","SRS",FileText],["1 click","Booking",BookMarked]].map(([value,label,Icon]: any) => <div key={label} className="rounded-2xl border border-white/10 bg-white/[.055] p-5 backdrop-blur"><Icon className="mb-5 h-6 w-6 text-cyan-300" /><b className="block text-2xl">{value}</b><span className="text-sm text-slate-400">{label}</span></div>)}
            </div>
          </div>
        </section>
        <section className="mx-auto max-w-7xl px-5 py-10">
          <div className="mb-8 grid gap-4 rounded-2xl border border-white/10 bg-[#0c1a2b] p-4 md:grid-cols-[1fr_230px_auto]">
            <label className="relative"><Search className="absolute left-4 top-3.5 h-5 w-5 text-slate-500" /><Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search by title, field, or keyword..." className="h-12 border-white/10 bg-[#07111f] pl-12 text-white placeholder:text-slate-500" /></label>
            <Select value={category} onValueChange={setCategory}><SelectTrigger className="h-12 w-full border-white/10 bg-[#07111f] text-white"><SelectValue /></SelectTrigger><SelectContent>{[...categories, ...(custom.length ? ["Custom"] : [])].map((item) => <SelectItem key={item} value={item}>{item}</SelectItem>)}</SelectContent></Select>
            <div className="flex items-center justify-center rounded-xl bg-white/5 px-5 text-sm text-slate-300">{filtered.length} ideas</div>
          </div>
          {visible.length ? <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">{visible.map((idea) => <article key={idea.id} className={`group relative overflow-hidden rounded-2xl border p-6 transition ${idea.booked ? "border-white/5 bg-white/[.025]" : "border-white/10 bg-[#0d1b2d] hover:-translate-y-1 hover:border-cyan-300/35"}`}>
            <div className={idea.booked ? "select-none blur-[5px] opacity-35" : ""}><div className="mb-5 flex items-center justify-between"><span className="rounded-full bg-cyan-300/10 px-3 py-1 text-xs font-bold text-cyan-300">{idea.category}</span><span className="font-mono text-xs text-slate-500">{idea.id}</span></div><h2 className="text-xl font-bold leading-snug">{idea.title}</h2><p className="mt-3 line-clamp-4 leading-7 text-slate-400">{idea.description}</p><Button onClick={() => setSelected(idea)} className="mt-6 w-full bg-white/8 text-white hover:bg-cyan-300 hover:text-[#06111e]">View idea <ArrowRight /></Button></div>
            {idea.booked && <div className="absolute inset-0 grid place-items-center"><div className="rounded-xl border border-amber-300/30 bg-[#07111f]/90 px-5 py-3 text-sm font-bold text-amber-300"><LockKeyhole className="mr-2 inline h-4 w-4" /> Already booked</div></div>}
          </article>)}</div> : <div className="py-24 text-center text-slate-400"><Search className="mx-auto mb-4 h-10 w-10" />No ideas match your search.</div>}
          <div className="mt-10 flex items-center justify-center gap-4"><Button variant="outline" disabled={page === 1} onClick={() => setPage(page - 1)} className="border-white/10 bg-transparent text-white"><ChevronLeft /> Previous</Button><span className="text-sm text-slate-400">Page {page} of {pages}</span><Button variant="outline" disabled={page === pages} onClick={() => setPage(page + 1)} className="border-white/10 bg-transparent text-white">Next <ChevronRight /></Button></div>
        </section>
       </main>}

      <footer className="border-t border-white/10 bg-[#050c16]"><div className="mx-auto flex max-w-7xl flex-col gap-6 px-5 py-10 sm:flex-row sm:items-center sm:justify-between"><div className="flex items-center gap-3"><img src="/echo-logo.svg" alt="" className="h-10 w-10 rounded-lg bg-white p-1" /><div><b>Echo Phantom</b><p className="text-sm text-slate-500">Technology shaped around real problems.</p></div></div><div className="flex gap-5 text-sm text-slate-400"><button onClick={() => navigate("/")}>Ideas</button><button onClick={() => navigate("/demo-srs")}>Demo SRS</button><button onClick={() => navigate("/about")}>About</button></div></div></footer>

      <Dialog open={loginOpen} onOpenChange={setLoginOpen}><DialogContent className="border-white/10 bg-[#0c1a2b] text-white"><DialogHeader><DialogTitle className="flex items-center gap-2 text-2xl"><GraduationCap className="text-cyan-300" /> Student Login</DialogTitle><DialogDescription className="text-slate-400">Enter your name and university roll number to book an idea.</DialogDescription></DialogHeader><form onSubmit={login} className="space-y-4"><Input name="name" required placeholder="Your full name" className="h-12 border-white/10 bg-[#07111f]" /><Input name="rollNumber" required placeholder="University roll number" className="h-12 border-white/10 bg-[#07111f]" /><Button className="h-12 w-full bg-cyan-300 text-[#06111e] hover:bg-cyan-200"><LogIn /> Continue</Button></form></DialogContent></Dialog>
      <Dialog open={!!selected} onOpenChange={(open) => !open && setSelected(null)}><DialogContent className="max-w-2xl border-white/10 bg-[#0c1a2b] text-white">{selected && <><DialogHeader><div className="mb-3 flex gap-2"><span className="rounded-full bg-cyan-300/10 px-3 py-1 text-xs font-bold text-cyan-300">{selected.category}</span><span className="rounded-full bg-white/5 px-3 py-1 font-mono text-xs text-slate-400">{selected.id}</span></div><DialogTitle className="text-2xl leading-tight">{selected.title}</DialogTitle><DialogDescription className="pt-3 text-base leading-7 text-slate-300">{selected.description}</DialogDescription></DialogHeader><div className="grid gap-3 sm:grid-cols-2"><Button disabled={selected.booked} onClick={() => book(selected)} className="h-12 bg-cyan-300 text-[#06111e] hover:bg-cyan-200"><BookMarked /> {selected.booked ? "Already booked" : "Book idea"}</Button><Button onClick={() => { setSelected(null); navigate(`/get-srs?idea=${selected.id}`); }} variant="outline" className="h-12 border-white/15 bg-transparent text-white hover:bg-white/10"><FileText /> Get SRS — Rs 100</Button></div></>}</DialogContent></Dialog>
    </div>
  );
}

function GetSrs() { return <main className="mx-auto grid min-h-[70vh] max-w-5xl place-items-center px-5 py-16"><section className="w-full rounded-[2rem] border border-cyan-300/20 bg-[radial-gradient(circle_at_top_right,rgba(34,211,238,.18),transparent_38%),#0c1a2b] p-8 text-center sm:p-14"><div className="mx-auto grid h-20 w-20 place-items-center rounded-3xl bg-[#25D366] shadow-[0_0_50px_rgba(37,211,102,.25)]"><MessageCircle className="h-10 w-10 text-white" /></div><p className="mt-8 text-sm font-bold uppercase tracking-[.24em] text-cyan-300">Project documentation</p><h1 className="mt-3 text-4xl font-black sm:text-5xl">Contact us to get SRS</h1><p className="mx-auto mt-5 max-w-xl text-lg leading-8 text-slate-300">A project SRS is available for <b className="text-white">Rs 100</b>. Message Echo Phantom on WhatsApp and mention the idea code.</p><a href="https://wa.me/923091949055?text=Hello%20Echo%20Phantom%2C%20I%20want%20to%20get%20a%20project%20SRS%20for%20Rs%20100." target="_blank" rel="noreferrer"><Button className="mt-8 h-14 rounded-2xl bg-[#25D366] px-8 text-base text-white hover:bg-[#20bd5a]"><MessageCircle /> WhatsApp 923091949055</Button></a></section></main>; }

function DemoSrs({ files }: { files: DemoFile[] }) { return <main className="mx-auto min-h-[70vh] max-w-6xl px-5 py-14"><div className="mb-10"><span className="text-sm font-bold uppercase tracking-[.22em] text-cyan-300">Reference library</span><h1 className="mt-3 text-4xl font-black">Demo SRS</h1><p className="mt-3 max-w-2xl text-slate-400">Review sample Software Requirements Specification files uploaded by Echo Phantom.</p></div>{files.length ? <div className="grid gap-5 md:grid-cols-2">{files.map((file) => <a key={file.object_key} href={`/api/srs?key=${encodeURIComponent(file.object_key)}`} target="_blank" className="flex items-center gap-5 rounded-2xl border border-white/10 bg-[#0c1a2b] p-6 hover:border-cyan-300/35"><div className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-cyan-300/10"><FileText className="text-cyan-300" /></div><div className="min-w-0"><b className="block truncate text-lg">{file.title}</b><span className="block truncate text-sm text-slate-500">{file.file_name}</span></div><ArrowRight className="ml-auto text-slate-500" /></a>)}</div> : <div className="rounded-3xl border border-dashed border-white/15 py-24 text-center text-slate-400"><BookOpen className="mx-auto mb-4 h-12 w-12 text-cyan-300" /><h2 className="text-xl font-bold text-white">Demo files are coming soon</h2><p className="mt-2">The admin can upload PDF or DOCX examples here.</p></div>}</main>; }

function About() { const services = [[Code2,"Full Stack Web Development"],[Sparkles,"App Development"],[LayoutDashboard,"Inventory Systems"],[ShieldCheck,"Desktop Applications"],[GraduationCap,"Custom AI Models"]]; return <main><section className="mx-auto max-w-7xl px-5 py-16 sm:py-24"><div className="grid items-center gap-12 lg:grid-cols-[.9fr_1.1fr]"><div className="relative"><div className="absolute inset-0 rounded-full bg-cyan-300/20 blur-3xl" /><img src="/echo-logo.svg" alt="Echo Phantom logo" className="relative mx-auto w-full max-w-sm" /></div><div><span className="text-sm font-bold uppercase tracking-[.22em] text-cyan-300">About Echo Phantom</span><h1 className="mt-4 text-4xl font-black leading-tight sm:text-6xl">We turn ambitious ideas into working technology.</h1><p className="mt-6 text-lg leading-8 text-slate-300">Echo Phantom supports students, startups, and businesses with thoughtful software design, dependable development, and practical AI solutions.</p></div></div></section><section className="border-y border-white/10 bg-white/[.025]"><div className="mx-auto max-w-7xl px-5 py-14"><h2 className="mb-8 text-3xl font-black">Our services</h2><div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">{services.map(([Icon,label]: any) => <article key={label} className="rounded-2xl border border-white/10 bg-[#0c1a2b] p-6"><Icon className="mb-8 h-7 w-7 text-cyan-300" /><h3 className="font-bold leading-snug">{label}</h3></article>)}</div></div></section></main>; }

function Admin({ session, reload, bookedIdeas }: { session: Session | null; reload: () => Promise<void>; bookedIdeas: Idea[] }) {
  const [paste, setPaste] = useState(""); const [uploading, setUploading] = useState(false);
  if (!session?.isAdmin) return <main className="grid min-h-[70vh] place-items-center px-5 text-center"><div><LockKeyhole className="mx-auto mb-5 h-12 w-12 text-amber-300" /><h1 className="text-3xl font-black">Admin access required</h1><p className="mt-3 text-slate-400">Log in with the authorized admin account to open this portal.</p></div></main>;
  const addIdeas = async () => { const ideas = parseIdeas(paste); if (!ideas.length) return toast.error("Paste at least one project idea."); const response = await fetch("/api/ideas", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action: "add", ideas }) }); const result = await response.json(); if (!response.ok) return toast.error(result.error); setPaste(""); await reload(); toast.success(`${result.added} ideas added and organized`); };
  const unbook = async (idea: Idea) => { const response = await fetch("/api/ideas", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action: "unbook", ideaId: idea.id }) }); const result = await response.json(); if (!response.ok) return toast.error(result.error); await reload(); toast.success(`${idea.id} is available again`); };
  const upload = async (event: React.FormEvent<HTMLFormElement>) => { event.preventDefault(); setUploading(true); const response = await fetch("/api/srs", { method: "POST", body: new FormData(event.currentTarget) }); const result = await response.json(); setUploading(false); if (!response.ok) return toast.error(result.error); event.currentTarget.reset(); await reload(); toast.success("Demo SRS uploaded"); };
  return <main className="mx-auto min-h-[70vh] max-w-7xl px-5 py-12"><div className="mb-10 flex items-end justify-between"><div><span className="text-sm font-bold uppercase tracking-[.22em] text-amber-300">Admin Portal</span><h1 className="mt-2 text-4xl font-black">Content control room</h1></div><div className="hidden rounded-xl border border-amber-300/20 bg-amber-300/10 px-4 py-2 text-sm text-amber-200 sm:block"><ShieldCheck className="mr-2 inline h-4 w-4" /> Authorized admin</div></div><div className="grid gap-6 lg:grid-cols-2"><section className="rounded-3xl border border-white/10 bg-[#0c1a2b] p-6 sm:p-8"><div className="mb-6 flex items-center gap-3"><div className="grid h-11 w-11 place-items-center rounded-xl bg-cyan-300/10"><Plus className="text-cyan-300" /></div><div><h2 className="text-xl font-bold">Paste project ideas</h2><p className="text-sm text-slate-400">One numbered “title - description” per line.</p></div></div><Textarea value={paste} onChange={(e) => setPaste(e.target.value)} rows={13} placeholder={"1. Smart Waste Vision - Detects recyclable materials using computer vision.\n2. Flood Risk Mapper - Predicts local flood risk using sensor data."} className="border-white/10 bg-[#07111f] leading-7" /><Button onClick={addIdeas} className="mt-4 h-12 w-full bg-cyan-300 text-[#06111e]"><Sparkles /> Organize & publish ideas</Button></section><section className="rounded-3xl border border-white/10 bg-[#0c1a2b] p-6 sm:p-8"><div className="mb-6 flex items-center gap-3"><div className="grid h-11 w-11 place-items-center rounded-xl bg-violet-400/10"><Upload className="text-violet-300" /></div><div><h2 className="text-xl font-bold">Upload Demo SRS</h2><p className="text-sm text-slate-400">PDF or DOCX, maximum 15 MB.</p></div></div><form onSubmit={upload} className="space-y-4"><Input name="title" required placeholder="Demo SRS title" className="h-12 border-white/10 bg-[#07111f]" /><label className="grid min-h-48 cursor-pointer place-items-center rounded-2xl border border-dashed border-white/15 bg-[#07111f] p-6 text-center hover:border-violet-300/40"><div><FileText className="mx-auto mb-3 h-10 w-10 text-violet-300" /><span className="font-semibold">Choose an SRS file</span><small className="mt-1 block text-slate-500">PDF or DOCX</small></div><input name="file" type="file" accept=".pdf,.docx" required className="sr-only" /></label><Button disabled={uploading} className="h-12 w-full bg-violet-400 text-[#07111f] hover:bg-violet-300"><Upload /> {uploading ? "Uploading..." : "Upload Demo SRS"}</Button></form></section></div><section className="mt-6 rounded-3xl border border-white/10 bg-[#0c1a2b] p-6 sm:p-8"><div className="mb-6 flex items-center gap-3"><div className="grid h-11 w-11 place-items-center rounded-xl bg-amber-300/10"><RotateCcw className="text-amber-300" /></div><div><h2 className="text-xl font-bold">Booked projects</h2><p className="text-sm text-slate-400">Reverse a booking to make the project available to students again.</p></div></div>{bookedIdeas.length ? <div className="grid gap-3">{bookedIdeas.map((idea) => <div key={idea.id} className="flex flex-col gap-4 rounded-2xl border border-white/10 bg-[#07111f] p-4 sm:flex-row sm:items-center"><div className="min-w-0 flex-1"><div className="mb-1 font-mono text-xs text-cyan-300">{idea.id}</div><div className="truncate font-semibold">{idea.title}</div></div><Button onClick={() => unbook(idea)} variant="outline" className="shrink-0 border-amber-300/25 bg-amber-300/10 text-amber-200 hover:bg-amber-300 hover:text-[#07111f]"><RotateCcw /> Make available again</Button></div>)}</div> : <div className="rounded-2xl border border-dashed border-white/15 py-12 text-center text-slate-400"><Check className="mx-auto mb-3 h-8 w-8 text-cyan-300" />No projects are currently booked.</div>}</section></main>;
}
