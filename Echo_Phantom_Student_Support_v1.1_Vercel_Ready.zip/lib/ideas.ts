export type Idea = { id: string; title: string; description: string; category: string; booked?: boolean };

const domains = [
  ["Artificial Intelligence", "AI"], ["Cybersecurity", "Security"], ["Climate Technology", "Climate"], ["Accessibility", "Accessibility"],
  ["Education Technology", "EdTech"], ["Agriculture Technology", "AgriTech"], ["Public Safety", "Safety"], ["Digital Heritage", "Heritage"],
  ["Legal Technology", "LegalTech"], ["Disaster Resilience", "Resilience"], ["Health Innovation", "HealthTech"], ["Transport Intelligence", "Mobility"],
  ["Energy Intelligence", "Energy"], ["Water Conservation", "Water"], ["Language Technology", "Language"], ["Privacy Engineering", "Privacy"],
  ["Media Verification", "MediaTech"], ["Smart Communities", "CivicTech"], ["Robotics", "Robotics"], ["Space & Earth Observation", "SpaceTech"],
] as const;

const concepts = [
  ["Anomaly Sentinel", "detects unusual patterns and explains why they matter in real time"],
  ["Predictive Signal Lab", "forecasts emerging risks from live and historical signals"],
  ["Adaptive Learning Engine", "personalizes guidance using measurable user progress"],
  ["Offline-First Field Assistant", "supports field work without reliable internet and syncs safely later"],
  ["Digital Twin Simulator", "models changing real-world conditions for safer decisions"],
  ["Computer Vision Inspector", "identifies visual defects, hazards, or changes from camera input"],
  ["Explainable Recommendation Studio", "recommends actions while showing evidence and tradeoffs"],
  ["Voice Navigation Companion", "enables hands-free interaction through multilingual speech"],
  ["Privacy-Preserving Analytics Lab", "produces useful insights without exposing personal records"],
  ["Crowdsourced Verification Network", "combines community reports with confidence scoring"],
  ["AR Guidance Lens", "overlays contextual instructions onto a live environment"],
  ["Resource Optimization Engine", "allocates limited resources using transparent constraints"],
  ["Early Warning Mapper", "maps risk hotspots and sends evidence-based alerts"],
  ["Behavior Change Coach", "uses gentle interventions and progress feedback to improve outcomes"],
  ["Synthetic Data Workbench", "creates safe representative datasets for testing and training"],
  ["Edge Intelligence Monitor", "runs lightweight detection directly on low-cost devices"],
  ["Collaborative Decision Canvas", "helps groups compare evidence, uncertainty, and priorities"],
  ["Knowledge Graph Explorer", "connects scattered facts into a searchable relationship map"],
  ["Trust & Bias Auditor", "tests automated decisions for fairness, drift, and explainability"],
  ["Gamified Skill Challenge", "turns practical learning into measurable scenario-based challenges"],
  ["Sensor Fusion Observatory", "combines multiple sensors to improve situational awareness"],
  ["Natural Language Insight Desk", "turns complex data into plain-language answers and summaries"],
  ["Resilient Mesh Communicator", "maintains local communication when central networks fail"],
  ["What-If Policy Sandbox", "simulates policy choices and visualizes likely consequences"],
  ["Human-in-the-Loop Automation", "automates repetitive analysis while keeping critical decisions with people"],
] as const;

export const builtInIdeas: Idea[] = domains.flatMap(([domain, category], di) =>
  concepts.map(([concept, purpose], ci) => ({
    id: `EP-${String(di * 25 + ci + 1).padStart(3, "0")}`,
    title: `${domain} ${concept}`,
    category,
    description: `A development-focused final year project that ${purpose}, tailored specifically to ${domain.toLowerCase()}. It includes a working prototype, measurable evaluation, and a practical user workflow rather than a traditional CRUD management portal.`,
  }))
);

export const categories = ["All", ...Array.from(new Set(builtInIdeas.map((idea) => idea.category)))];
