import { cookies } from "next/headers";

export type Session = { name: string; rollNumber: string; isAdmin: boolean };
const encode = (value: string) => btoa(unescape(encodeURIComponent(value))).replaceAll("=", "");
const decode = (value: string) => decodeURIComponent(escape(atob(value)));

async function sign(payload: string) {
  const secret = process.env.SESSION_SECRET;
  if (!secret) throw new Error("SESSION_SECRET is not configured.");
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const signature = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(payload));
  return Array.from(new Uint8Array(signature)).map((byte) => byte.toString(16).padStart(2, "0")).join("");
}

export async function createSession(session: Session) {
  const payload = encode(JSON.stringify(session));
  const token = `${payload}.${await sign(payload)}`;
  (await cookies()).set("echo_session", token, { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", path: "/", maxAge: 60 * 60 * 24 * 14 });
}

export async function getSession(): Promise<Session | null> {
  const token = (await cookies()).get("echo_session")?.value;
  if (!token) return null;
  const [payload, signature] = token.split(".");
  if (!payload || !signature || (await sign(payload)) !== signature) return null;
  try { return JSON.parse(decode(payload)); } catch { return null; }
}

export async function clearSession() { (await cookies()).delete("echo_session"); }
